package org.anonbnr.design_patterns.architectural.service_locator;

public interface MessagingService {
	/* METHODS */
	String getMessageBody();
	String getServiceName();
}
