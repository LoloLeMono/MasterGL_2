package org.anonbnr.design_patterns.oop.creational.abstract_factory.automobile_industry;

// Abstract Product C
public interface Body {
    void shape();
}
